import re
import time
import unicodedata
from subprocess import Popen, PIPE
import matplotlib.pyplot as plt

class log():    #Use class to show log
    def __init__(self,verran):
        self.verran = verran    #the range in a certain version
        self.repo = "D:\git\data\linux-stable"    #the data adress45
        self.commit_time = {}
        self.commit = re.compile('^commit [0-9a-z]{40}$', re.IGNORECASE)    #the re to capture every commit
        #self.fixes  = re.compile('^\W+Fixes: [a-f0-9]{8,40} \(.*\)$', re.IGNORECASE)    #the re to capture every fix
        self.date = re.compile('^Date:\s+(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) ([1-9]|[1-2]\d|3[0-1]) [0-9]{2}:[0-9]{2}:[0-9]{2} [0-9]{4} (\+|\-)[0-9]{4}$', re.IGNORECASE)
                #the re to capture every date
    def get_data(self,verran):
        cmd = ["git", "log", "-P", "--no-merges", self.verran]
        p = Popen(cmd, cwd=self.repo, stdout=PIPE)
        data, res = p.communicate()
        data = unicodedata.normalize(u'NFKD', data.decode(encoding="utf-8", errors="ignore"))
        return data

    def time_transfer(self,t):
        date = time.strptime(t[12:],'%b %d %H:%M:%S %Y %z')
        timeStamp = int(time.mktime(date))
        #print (timeStamp)
        return (timeStamp)

    def get_commit_time(self):
        sum1 = 0
        for line in self.get_data(self.verran).split("\n"):
            if(self.commit.match(line)):
                cur_date = line
            if(self.date.match(line)):
                sum1 += 1
                self.commit_time.update({sum1:[cur_date[7:14],self.time_transfer(line)]})
        print("There are total ",sum1," commits!", end="\n")
        return self.commit_time
    

        
        
def main():
    lst1=[]
    lst2=[]
    b = log("v4.1..v4.5").get_commit_time()
    for i in b.keys():
        lst1.append(i)
    for i in b.items():
        lst2.append(i[1])
    plt.plot(lst1,lst2,linewidth=1)
    plt.xlabel('x轴',fontsize=1000)
    plt.ylabel('y轴',fontsize=1000)
    plt.show()


if __name__ == "__main__":
    main() 
          
            
       

