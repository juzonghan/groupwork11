import re
import unicodedata
from subprocess import Popen, PIPE

commit = re.compile('^commit [0-9a-z]{40}$', re.IGNORECASE)
fixes  = re.compile('^\W+Fixes: [a-f0-9]{8,40} \(.*\)$', re.IGNORECASE)

def gitFixCommits(kernelRange, repo):
    nr_fixes = 0
    cmd = ["git", "log", "-P", "--no-merges", kernelRange]
    p = Popen(cmd, cwd=repo, stdout=PIPE)
    data, res = p.communicate()
    # we need to clean and normalize the data - note the errors ignore !
    sum1 = 0
    data = unicodedata.normalize(u'NFKD', data.decode(encoding="utf-8", errors="ignore"))
    for line in data.split("\n"):
        if(commit.match(line)):
            cur_commit = line
            sum1 += 1
        if(fixes.match(line)):
            # we have a fixes tag 
            nr_fixes += 1
            # just emit the two hashes - the secnd one is
            # shortened to 7 == shortest fixes tag I found
            print(cur_commit[7:19],",",line.strip()[9:16],sep="")
    print("total found fixes:",nr_fixes,sum1)

gitFixCommits("v4.9..v4.9.21", "D:/kernel/linux-stable")
