"""run through the git log as a stream and find all lines that incdicate a new
   commit - within that block that belongs to a commit
   search for a "  Fixes: SHA (text)" line and report it

   No additional meta-data is currently extracted - thats 
   your job ;) """

import re
from subprocess import Popen, PIPE

#The regex that describe the beginning of a commit in the git log
#and the line that has a fixes tag - note that this will only
#count those fixes tags that are on a line on their own !
commit = re.compile('^commit [0-9a-z]{40}$', re.IGNORECASE)
fixes  = re.compile('^\W+Fixes: [a-f0-9]{8,40} \(.*\)$', re.IGNORECASE)

def gitFixCommits(fileName, kernelRange, repo):
    """iterate over the git log and for each commit that
       is found extract any Fixes tag in it - only report
       if one is found"""
    nr_fixes = 0
    total_commits = 0
    cmd = ["git", "log", "-P", kernelRange, fileName]
    p = Popen(cmd, cwd=repo, stdout=PIPE)
    data, res = p.communicate()
    # take the complete log and now "parse" it - this
    # is a stupid stateless parser only ...
    for line in data.decode("utf-8").split("\n"):
        if(commit.match(line)):
            # record the curent commit - anything following
            # here until the next "commit ..." line is the
            # the current commit.
            cur_commit = line
            total_commits += 1
        if(fixes.match(line)):
            # we have a fixes tag in the current commit so
            # process it - here we only print it...
            nr_fixes += 1
            print(cur_commit,"\n\t", line.strip())
    #report average number of fixes in total commits
    #is this a bugginess indicator ??
    fixes_percent = (nr_fixes/total_commits)*100
    #Use the new style f - not "old style" .format - please !
    #print("fixes in {}: {} ({:4.2f}%)".format(fileName, nr_fixes, fixes_percent))
    print(f"fixes in {fileName}: {nr_fixes} ({fixes_percent:4.2f}%)")

# could we "iterating" over two files/directories with this ???
gitFixCommits("kernel/sched/core.c", "v3.0..HEAD", "/home/hofrat/git/linux-stable")
gitFixCommits("kernel/sched/cpudeadline.c", "v3.0..HEAD", "/home/hofrat/git/linux-stable")
