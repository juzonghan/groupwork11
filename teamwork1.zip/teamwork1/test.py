#!/usr/bin/env python3
import re
import time
from datetime import datetime
import unicodedata
from subprocess import Popen, PIPE
lst = []
rex = re.compile('^Date:\s+(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) ([1-9]|[1-2]\d|3[0-1]) [0-9]{2}:[0-9]{2}:[0-9]{2} [0-9]{4} (\+|\-)[0-9]{4}$', re.IGNORECASE)
commit = re.compile('^commit [0-9a-z]{40}$', re.IGNORECASE)
fixes  = re.compile('^\W+Fixes: [a-f0-9]{8,40} \(.*\)$', re.IGNORECASE)
kernelRange = "v4.1..head"
repo = "D:/kernel/linux-stable"
#cmd = ["git", "log", "-P", "--no-merges","--pretty=format:\"%ct\" ", kernelRange]
cmd = ["git", "log", "-P", "--no-merges", kernelRange]
p = Popen(cmd, cwd=repo, stdout=PIPE)
data, res = p.communicate()
#p = Popen(cmd, cwd=repo, stdout=PIPE)
#data, res = p.communicate()
sum1 = 0
sum2 = 0
data = unicodedata.normalize(u'NFKD', data.decode(encoding="utf-8", errors="ignore"))
#for i in data.split( ):
    #sum1 += 1
"""for line in data.split("\n"):
    if(rex.match(line)):
        cur_commit = line
        date = time.strptime(line[12:],'%b %d %H:%M:%S %Y %z')
        timeStamp = int(time.mktime(date))
        #print(timeStamp)
    """
        #sum1 += 1
    if(commit.match(line)):
        lst.append(line[7:14])
        #print(line[7:14])
    if(fixes.match(line)):
        for i in lst:
            if i == line[11:18]:
                sum1+=1
        #print(line[11:18])
        #sum1 += 1
    
    
#print(data)
print(sum1)

