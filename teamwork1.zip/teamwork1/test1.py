import re
rex = re.compile('^Date:\s+(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sept|Oct|Nov|Dec) ([1-9]|[1-2]\d|3[0-1]) [0-9]{2}:[0-9]{2}:[0-9]{2} [0-9]{4} \+[0-9]{4}$', re.IGNORECASE)
string = 'Date:   Thu Feb 25 12:01:36 2016 +8080'
if(rex.match(string)):
    print(string)
